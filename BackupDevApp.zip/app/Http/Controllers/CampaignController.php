<?php

namespace App\Http\Controllers;

use Cache;
use Inertia\Inertia;
use App\Models\Account;
use App\Models\Campaign;
use App\Models\Contact;
use App\Http\Controllers\Controller;
use App\Models\Msg;
use App\Http\Controllers\MsgController;
use App\Models\Taggable;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Models\Template;

class CampaignController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $list_view_columns = [
            'name' => ['label' => __('Name'), 'type' => 'text'],
            'status' =>  ['label' => __('Status'), 'type' => 'text'],
            'service' =>  ['label' => __('Service'), 'type' => 'text'],
            'scheduled_at' => ['label' => __('Scheduled'), 'type' => 'text'],
        ];

        $module = new Campaign();
        $listViewData = $this->listView($request, $module, $list_view_columns);
        $menuBar = $this->fetchMenuBar();

        $moduleData = [
            'singular' => __('Campaign'),
            'plural' => __('Campaigns'),
            'module' => 'Campaign',
            'current_page' => 'Campaigns', 
            // Actions
            'actions' => [
                'create' => true,
                'detail' => true,
                'edit' => false,
                'delete' => true,
                'export' => false,
                'import' => false,
                'search' => true,
                'filter' => true,
                'select_field'=>true
            ],
            'menuBar' => $menuBar
        ];
        
        $data = array_merge($moduleData, $listViewData);
        return Inertia::render('Campaign/List', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, Campaign $campaign)
    { 
        if($request){
            $request->validate([
                'name' => 'required'
            ]);
        }

        $user_id = $request->user()->id;
        $company_id = 1;
        $translator = Controller::getTranslations();
        $filter = Controller::getFiltersInfo($company_id, $user_id, 'Campaign', '');
        $count = '';

        if($request->id){
 
            $campaign = Campaign::findOrFail($request->id);
            $currentPage = $request->tab;
                 
            if($request->name){
                $campaign->name = $request->name;
                $campaign->service = $request->service;
                $campaign->account_id = $request->account_id;
                $campaign->template_id = $request->template_id;
            }
            if($request->conditions){
                $conditions = json_encode($request->conditions);
                $campaign->conditions = $conditions;
            }
            if($request->scheduled_at){
                $scheduledTime = $request->scheduled_at;
                if($scheduledTime == 'now'){
                    $currentDate = gmdate('Y-m-d h:i:s');
                    $campaign->scheduled_at = $currentDate;
                }else{
                    $scheduledTime = date( 'Y-m-d h:i:s', strtotime( $scheduledTime) );
                    $campaign->scheduled_at = $scheduledTime;
                } 
            }
        
            if($currentPage == 4){
                $campaign->offset = 0;
                $campaign->current_page = $currentPage;
                $campaign->status = 'new';
                $campaign->save();

                return Redirect::route('listCampaign');
            }

            $campaign->current_page = $currentPage + 1;
            $campaign->save();

            if($campaign->conditions){
                $searchData = json_decode($campaign->conditions);
                $contacts = $this->getTotalContact($searchData);
                $count = count($contacts);
                $campaign->conditions = $searchData;
            }

        }else{
            $campaign->name = $request->name;
            $campaign->status = 'draft';
            $campaign->company_id = $company_id;
            $campaign->current_page = 1;
            $campaign->save();
        }

        return Inertia::render('Campaign/Form',[
            'translator' => $translator, 
            'filter' => $filter,
            'campaign' => $campaign,
            'status' => $campaign->status,
            'count' => $count,
        ]); 
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Campaign  $campaign
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {
        $module = new Campaign();
        $campaign = $this->checkAccessPermission($request, $module, $id);

        if(!$campaign){
            abort('404');
        } 

        $company_id = Cache::get('selected_company_'.$request->user()->id);
        
        $count = '';
        $companyName = [];
        $status = $campaign->status;
        $conditions = $campaign->conditions;
  
        if($conditions){
            $searchData = json_decode($conditions);
            $campaign->conditions = $searchData;
            $contacts = $this->getTotalContact($searchData);
            $count = count($contacts);
        };
      
        if($campaign->service){
            $accounts = Account::where('company_id',$company_id)
                        ->where('service',$campaign->service)          
                        ->get();

            foreach($accounts as $account){
                  $companyName[$account->id] = $account->company_name;
            }
        }

        $user_id = $request->user()->id;
        $translator = Controller::getTranslations();
        $filter = Controller::getFiltersInfo($company_id, $user_id, 'Campaign', '');
    
        return Inertia::render('Campaign/Form',[
            'translator' => $translator, 
            'filter' => $filter, 
            'campaign' => $campaign, 
            'status' => $status,
            'count' => $count, 
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Campaign  $campaign
     * @return \Illuminate\Http\Response
     */
    public function edit(Campaign $campaign)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Campaign  $campaign
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Campaign $campaign)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Campaign  $campaign
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        $campaign = Campaign::find($id);
        $campaign->delete();
        return Redirect::route('listCampaign');
    }

    public function searchRecords(Request $request){

        $module = new Contact();
        $list_view_columns = $module->getListViewFields();
        $listViewData = $this->listView($request, $module, $list_view_columns);

        echo $listViewData;
    } 

    public function getTotalContact($searchData){

        $module = new Contact(); 

        $fields = [
            'first_name' => ['label' => __('First Name'), 'type' => 'text'],
            'last_name' =>  ['label' => __('Last Name'), 'type' => 'text'],
            'email' =>  ['label' => __('Email'), 'type' => 'text'],
            'phone_number' => ['label' => __('Phone number'), 'type' => 'phone_number'],
            'instagram_username' => ['label' =>_('Instagram Username'), 'type' => 'text'],
        ];       
        
        $contacts = $this->getContactRecords($module, $fields, $searchData, '', '');
        
        return $contacts;
    }

    public function getCompanyName(Request $request, $service){
        
        if($service){
            $user_id = $request->user()->id;
            $company_id = Cache::get('selected_company_'.$user_id);

            $accounts = Account::where('company_id',$company_id)
                        ->where('service',$service)          
                        ->get();

            foreach($accounts as $account){
                  $companyName[$account->id] = $account->company_name;
            }
        }

        echo json_encode($companyName); die;
    }

    /**
     * Get template list
     */
    public function getTemplateList(Request $request, $account)
    {
        $templateList = [];
        $templates = Template::where('account_id', $account)->get();
        foreach($templates as $template){
            $templateList[$template->template_uid] = $template->name;
        }
        return response()->json(['templates' => $templateList]);
    }
}
